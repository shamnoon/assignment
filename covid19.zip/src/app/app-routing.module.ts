import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'live', pathMatch: 'full'},
  { path : 'country', loadChildren: () => import('./features/country/country.module').then(m => m.CountryModule)},
  { path : 'live', loadChildren: () => import('./features/live/live.module').then(m => m.LiveModule)},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
