import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LiveRoutingModule } from './live-routing.module';
import { LiveComponent } from './live.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [
    LiveComponent
  ],
  imports: [
    CommonModule,
    LiveRoutingModule,
    HighchartsChartModule,
    SharedModule
  ]
})
export class LiveModule { }
