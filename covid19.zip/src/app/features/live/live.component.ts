import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import * as Highcharts from 'highcharts/highmaps';
import * as worldMap from '@highcharts/map-collection/custom/world.geo.json';
import * as countryJson from './countrycode.json';
import HC_exporting from 'highcharts/modules/exporting';
HC_exporting(Highcharts);
import { CovidService } from 'src/app/shared/service.service';
@Component({
  selector: 'app-live',
  templateUrl: './live.component.html',
  styleUrls: ['./live.component.scss']
})
export class LiveComponent implements OnInit, OnDestroy {
  constructor(private liveService: CovidService) { }
  Highcharts:any = Highcharts;
  chartConstructor = 'mapChart';
  liveData: any = [];
  chartOptions : Highcharts.Options | any = {
    chart: {
      map : worldMap
    },
    title: {
      text : 'COVID-19 World Data'
    },
    subtitle: {
      text : 'Confirmed Cases Live'
    },
    mapNavigation : {
      enabled : true,
      buttonOptions: {
        alignTo : 'spacingBox'
      }
    },
    legend : {
      enabled :true
    },
    colorAxis: {
      min: 0
    },
    series:[{
      type : 'map',
      name : 'COVID-19 Data',
      states: {
        hover : {
          color : '#dc3545'
        }
      },
      dataLabels : {
        enabled :true,
        format: '{point.name}'
      },
      allAreas: false,
      data : []
    }]
  }

  ngOnInit(): void {
    var countryArray = Object.values(countryJson);
    this.liveService.getCountryStatistics().subscribe((data) => {
      data.response.forEach((elem: any) => {
        const found = countryArray.find((x) => x['CLDR display name'] === elem.country.replace('-', ' '));
        if(found?.MARC){
          const arrayData = [found?.MARC?.split(',')[0], Number(elem.cases.total)]
          this.liveData.push(arrayData);
        }        
      });
      this.chartOptions.series[0].data = this.liveData;
      this.Highcharts.mapChart('container', this.chartOptions);
    });
  }

  ngOnDestroy(){
  }

}
