import { Component, OnInit } from '@angular/core';
import { CovidService } from 'src/app/shared/service.service'; 
import { forkJoin } from 'rxjs';
@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.scss']
})
export class CountryComponent implements OnInit {
  countries: string[] = [];
  statistics: string[] = [];
  searchText: string;
  constructor(private countryService: CovidService) { }

  ngOnInit(): void {
    forkJoin([
      this.countryService.getCountries(), 
      this.countryService.getCountryStatistics()]).subscribe((data) => {
        this.countries = data[0].response;
        this.statistics = data[1].response;
      });
  }

  dataRecived(data:string){
    alert(data);
  }

}
