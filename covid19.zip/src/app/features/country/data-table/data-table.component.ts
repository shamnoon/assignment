import { AfterViewInit, Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';


@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit, AfterViewInit  {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @Input() data: any[] = [];
  @Input() searchText: string;
  displayedColumns: string[] = ['id', 'country', 'cases', 'recovered', 'deaths', 'population'];
  dataSource = new MatTableDataSource();  
  constructor() { }

  ngOnChanges(){
    this.applyFilter(this.searchText);
  }

  ngOnInit(): void {
    this.dataSource = new MatTableDataSource(this.data);
  } 

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: string) {
    if(event){
      this.dataSource.filter = event.trim().toLowerCase();
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }else{
      this.dataSource.filter = '';
    }    
  }

}
