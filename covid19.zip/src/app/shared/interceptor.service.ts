import { Injectable } from '@angular/core';
import { HttpHeaders, HttpInterceptor } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHandler } from '@angular/common/http';
import { HttpEvent } from '@angular/common/http';
import { CONSTANT } from '../constant';
@Injectable({
  providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor {
  constructor() { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    var headers: HttpHeaders = new HttpHeaders()
    .set("x-rapidapi-host", "covid-193.p.rapidapi.com")
    .set("x-rapidapi-key", CONSTANT.API_KEY);
    return next.handle(req.clone({ headers }));
  }
}