import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  @Input() data: string[] = [];
  @Output() searchData: EventEmitter<string> = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  search(value: string){
    this.searchData.emit(value);
  }

  isEmpty(value: string){
    if(!value){ this.search('');}
  }

}
