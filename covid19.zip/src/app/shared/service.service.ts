import { Injectable } from '@angular/core';
import { CONSTANT } from '../constant';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CovidService {

  constructor(private http: HttpClient) { }

  getCountries(): Observable<any>{
    return this.http.get(CONSTANT.API_URL + 'countries');
  }

  getCountryStatistics(): Observable<any>{
    return this.http.get(CONSTANT.API_URL + 'statistics');
  }

  getCaseByCountry(name : any): Observable<any>{
    return this.http.get(CONSTANT.API_URL + 'history?country=' + name);
  }
}
