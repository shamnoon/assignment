export const CONSTANT = {
    API_URL : 'https://covid-193.p.rapidapi.com/',
    API_KEY : 'd1780f3c56mshcc8d3edc81698f4p164e13jsna272587cbbc1'
}